package GrammaticalTools.GrammaticalTreeDef;

public class NodeStmt extends MyTreeNode {
    public NodeStmt(int lineNum) {
        super(lineNum);
    }
}
