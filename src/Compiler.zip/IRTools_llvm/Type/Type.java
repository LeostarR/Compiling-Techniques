package IRTools_llvm.Type;

public abstract class Type {
    public abstract int getSpace();
}
