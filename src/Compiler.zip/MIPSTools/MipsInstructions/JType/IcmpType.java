package MIPSTools.MipsInstructions.JType;

public enum IcmpType {
    seq,
    sne,
    sgt,
    sge,
    slt,
    sle;

    @Override
    public String toString() {
        return super.toString();
    }
}
