package MIPSTools.MipsInstructions;

public abstract class MIPSInstruction {

}
