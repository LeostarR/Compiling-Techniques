package MIPSTools.MipsInstructions.OtherType;

import MIPSTools.MipsInstructions.MIPSInstruction;

public class Syscall extends MIPSInstruction {
    @Override
    public String toString() {
        return "syscall";
    }
}
