package MIPSTools.MipsInstructions.BinaryType;

public enum BinaryPureType {
    addu,
    subu,
    and,
    or;

    @Override
    public String toString() {
        return super.toString();
    }
}
