package MIPSTools.MipsInstructions.BinaryType;

public enum BinaryImmeType {
    addi,   //符号加立即数
    andi,   //与立即数
    ori;    //或立即数

    @Override
    public String toString() {
        return super.toString();
    }
}
