package SymbolTools;

public enum IdentType {
    COMMONVAR,
    ONEDIMARR,
    TWODIMARR,
    FUNCTION
}

